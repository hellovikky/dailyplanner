import React, { useEffect, useMemo, useState } from 'react'
import type { Task } from './types'
import { useLocalStorage } from './hooks/useLocalStorage'
import TaskForm from './components/TaskForm'
import TaskList from './components/TaskList'

type Filter = 'all' | 'active' | 'completed'

const SAMPLE: Task[] = [
  {
    id: 't1',
    title: 'Пример задачи',
    description: 'Описание примера',
    dueDate: undefined,
    isCompleted: false
  }
]

const STORAGE_KEY = 'daily-planner.tasks.v1'

const App: React.FC = () => {
  const [tasks, setTasks] = useLocalStorage<Task[]>(STORAGE_KEY, SAMPLE)
  const [filter, setFilter] = useState<Filter>('all')

  useEffect(() => {
    // ensure tasks are valid (migration point)
    setTasks(prev => prev ?? [])
  }, [])

  const visible = useMemo(() => {
    switch (filter) {
      case 'active':
        return tasks.filter(t => !t.isCompleted)
      case 'completed':
        return tasks.filter(t => t.isCompleted)
      default:
        return tasks
    }
  }, [tasks, filter])

  const addTask = (task: Task) => {
    setTasks(prev => [task, ...prev])
  }

  const toggleTask = (id: string) => {
    setTasks(prev => prev.map(t => t.id === id ? { ...t, isCompleted: !t.isCompleted } : t))
  }

  const deleteTask = (id: string) => {
    setTasks(prev => prev.filter(t => t.id !== id))
  }

  return (
    <div className="container">
      <h1>Ежедневник</h1>
      <TaskForm onAdd={addTask} />
      <div className="filters">
        <button onClick={() => setFilter('all')} aria-pressed={filter === 'all'}>Все</button>
        <button onClick={() => setFilter('active')} aria-pressed={filter === 'active'}>Активные</button>
        <button onClick={() => setFilter('completed')} aria-pressed={filter === 'completed'}>Завершенные</button>
      </div>
      <TaskList tasks={visible} onToggle={toggleTask} onDelete={deleteTask} />
    </div>
  )
}

export default App
