import React from 'react'
import type { Task } from '../types'

interface Props {
  task: Task
  onToggle: (id: string) => void
  onDelete: (id: string) => void
}

const TaskItem: React.FC<Props> = ({ task, onToggle, onDelete }) => {
  return (
    <li className="task-item">
      <div>
        <input
          type="checkbox"
          checked={task.isCompleted}
          onChange={() => onToggle(task.id)}
        />
        <span className={task.isCompleted ? 'completed' : ''}>
          {task.title}
          {task.dueDate ? (
            <small className="due"> — {new Date(task.dueDate).toLocaleDateString()}</small>
          ) : null}
        </span>
      </div>
      {task.description ? <div className="desc">{task.description}</div> : null}
      <button className="delete" onClick={() => onDelete(task.id)}>Удалить</button>
    </li>
  )
}

export default TaskItem
